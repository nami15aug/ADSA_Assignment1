#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 100
#define NIL -1
struct edge
{
    int u;
    int v;
    int weight;
    struct edge *link;
}*front = NULL;

/* No of Vertices in the input Graph */
int n = 9;

/* Adjacency Matrix of the input Graph */
int adj[MAX][MAX] =
          {{0,   9,   0,   4,   2,   0,   0,   0,   0},
           {9,   0,  10,   0,   8,   0,   0,   0,   0},
           {0,  10,   0,   0,   7,   5,   0,   0,   0},
           {4,   0,   0,   0,   3,   0,  18,   0,   0},
           {2,   8,   7,   3,   0,   6,  11,  12,  15},
           {0,   0,   5,   0,   6,   0,   0,   0,  16},
           {0,   0,   0,  18,  11,   0,   0,  14,   0},
           {0,   0,   0,   0,  12,   0,  14,   0,  20},
           {0,   0,   0,   0,  15,  16,   0,  20,   0},
          };

/* Inserting edges in the linked priority queue */
void insert_pque(int i, int j, int wt)
{
    struct edge *tmp, *q;
    tmp = (struct edge*)malloc(sizeof(struct edge));
    tmp->u = i;
    tmp->v = j;
    tmp->weight = wt;
    /* Queue is empty or edge to be added has weight less than first edge */
    if((front==NULL) || (tmp->weight<front->weight))
    {
        tmp->link = front;
        front = tmp;
    }
    else
    {
        q = front;
        while(q->link != NULL && q->link->weight<=tmp->weight)
        {
            q = q->link;
        }
        tmp->link = q->link;
        q->link = tmp;
        if(q->link == NULL)     /* Edge to be added at the end */
        {
            tmp->link = NULL;
        }
    }
}

/* Deleting an edge from the linked priority queue */
struct edge *del_pque()
{
    struct edge *tmp;
    tmp = front;
    front = front->link;
    return tmp;
};

int isEmpty_pque()
{
    if(front==NULL)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void make_tree(struct edge tree[])
{
    struct edge *tmp;
    int v1, v2, root_v1, root_v2;
    int father[MAX]; /* Holds father of each vertex */
    int i, count=0; /* Denotes no. of edges included in the tree */
    for(i=0;i<n;i++)
    {
        father[i] = NIL;
    }
    /* Loop till queue becomes empty or till n-1 edges have been inserted in the tree */
    while(!isEmpty_pque() && count<n-1)
    {
        tmp = del_pque();
        v1 = tmp->u;
        v2 = tmp->v;
        while(v1 != NIL)
        {
            root_v1 = v1;
            v1 = father[v1];
        }
        while(v2 != NIL)
        {
            root_v2 = v2;
            v2 = father[v2];
        }
        if(root_v1 != root_v2) /* Insert the edge (v1, v2) */
        {
            count++;
            tree[count].u = tmp->u;
            tree[count].v = tmp->v;
            tree[count].weight = tmp->weight;
            father[root_v2] = root_v1;
        }
    }
    if(count<n-1)
    {
        printf("Graph is not connected, no spanning tree possible \n");
        exit(1);
    }
}

int main()
{
    printf("/**********************************/\n");
    printf("/  Executing Kruskal's Algorithm   /\n");
    printf("/**********************************/\n");

    int i,j, itr=0;
    struct edge tree[MAX]; /* Will contain the edges of spanning tree */
    int wt_tree = 0; /* Weight of the spanning tree */


    /* Fill the weights of the edges of undirected graph in queue */
    for(i=0; i< n; i++)
    {
        for(j=itr; j< n; j++)
        {
            if(0 != adj[i][j])
            {
                insert_pque(i,j,adj[i][j]);
            }
        }
        itr++;
    }


    make_tree(tree);
    printf("Edges to be included in minimum spanning tree are : \n");
    for(i=1; i<=n-1; i++)
    {
        printf("%d->", tree[i].u);
        printf("%d\n", tree[i].v);
        wt_tree += tree[i].weight;
    }
    printf("Weight of this minimum spanning tree is : %d\n", wt_tree);
}

