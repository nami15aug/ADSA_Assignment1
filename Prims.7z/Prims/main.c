#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX  10
#define TEMP 0
#define PERM 1
#define NIL -1
#define infinity 9999

struct edge
{
    int u;
    int v;
};

/* No of Vertices in the input Graph */
int n = 6;

/* Adjacency Matrix of the input undirected connected Graph */
int adj[MAX][MAX] =
          {{0,   6,   2,   3,  10,   0},
           {6,   0,   0,  11,   0,   9},
           {2,   0,   0,  14,   8,   0},
           {3,  11,  14,   0,   7,   5},
           {10,  0,   8,   7,   0,   4},
           {0,   9,   0,   5,   4,   0},
          };
int predecessor[MAX];
int length[MAX];
int status[MAX];

/* Returns the temporary vertex with min value of length.
 * Returns NIL if no temporary vertex is left or all temporary vertices that are left have infinity as pathlength
 */
int min_temp()
{
    int i;
    int min = infinity;
    int k = NIL;
    for(i = 0; i < n; i++)
    {
        if(status[i]==TEMP && length[i]<min)
        {
            min = length[i];
            k = i;
        }
    }
    return k;
}

void maketree(int r, struct edge tree[MAX])
{
    int current, i;
    int count = 0;
    for(i=0; i<n ; i++)
    {
        predecessor[i] = NIL;
        length[i] = infinity;
        status[i] = TEMP;
    }
    length[r] = 0;
    while(1)
    {
        /* Search for temporary vertex with min length and make it current vertex */
        current = min_temp();
        if(current == NIL)
        {
            if(count==n-1)
            {
                return;
            }
            else
            {
                printf("Graph is not connected, No spanning tree possible \n");
                exit(1);
            }
        }
        status[current] = PERM; /* Make the current vertex permanent */
        /* Insert the edge (predecessor[current], current) into the tree except when the current vertex is root */
        if(current != r)
        {
            count++;
            tree[count].u = predecessor[current];
            tree[count].v = current;
        }
        for(i=0; i<n; i++)
        {
            if(adj[current][i]>0 && status[i] == TEMP)
            {
                if(adj[current][i] < length[i])
                {
                    predecessor[i] = current;
                    length[i] = adj[current][i];
                }
            }
        }
    }
}

int main()
{
    printf("/**********************************/\n");
    printf("/  Executing Prim's Algorithm      /\n");
    printf("/**********************************/\n");

    int wt_tree = 0;
    int i;
    int root=0; /* Source Vertex */
    struct edge tree[MAX];
    maketree(root, tree);
    printf("Edges to be included in spanning tree are : \n");
    for(i=1;i<=n-1;i++)
    {
        printf("%d->", tree[i].u);
        printf("%d\n", tree[i].v);
        wt_tree += adj[tree[i].u][tree[i].v];
    }
    printf("Weight of spanning tree is : %d\n", wt_tree);

}
